const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const FirebaseStore = require('connect-session-firebase')(session);
const firebase = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Initialize Firebase
firebase.initializeApp({
  credential: firebase.credential.cert(serviceAccount),
  databaseURL: 'https://hashcode-78b45.firebaseio.com'
});

// Initialize the Firebase session store
const sessionStore = new FirebaseStore({
  database: firebase.database()
});

// Initialize the session middleware
app.use(session({
  store: sessionStore,
  secret: '<your-session-secret>',
  resave: false,
  saveUninitialized: true
}));

// Define a middleware function to require login for certain routes
const requireLogin = (req, res, next) => {
  if (req.session && req.session.user) {
    next();
  } else {
    res.redirect('/login');
  }
};

// Define routes for login, signup, and logout
app.get('/login', (req, res) => {
  res.sendFile(__dirname + '/views/login.html');
});

app.post('/login', (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  firebase.auth().signInWithEmailAndPassword(email, password)
    .then(() => {
      req.session.user = email;
      res.redirect('/counter');
    })
    .catch(error => {
      console.log(error);
      res.redirect('/login');
    });
});

app.get('/signup', (req, res) => {
  res.sendFile(__dirname + '/views/signup.html');
});

app.post('/signup', (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  firebase.auth().createUserWithEmailAndPassword(email, password)
    .then(() => {
      req.session.user = email;
      res.redirect('/counter');
    })
    .catch(error => {
      console.log(error);
      res.redirect('/signup');
    });
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// Define a route for the counter
app.get('/counter', requireLogin, (req, res) => {
  const counterRef = firebase.database().ref(`counters/${req.session.user}`);
  counterRef.once('value', snapshot => {
    const count = snapshot.val() || 0;
    res.send(`
      <h1>Welcome ${req.session.user}!</h1>
      <p>Your count is ${count}.</p>
      <form method="POST" action="/increment">
        <button>Increment</button>
      </form>
      <form method="POST" action="/decrement">
        <button>Decrement</button>
      </form>
      <form method="POST" action="/reset">
        <button>Reset</button>
      </form>
      <form method="POST" action="/logout">
        <button>Logout</button>
      </form>
    `);
  });
});

// Define routes for increment, decrement, and reset
// Define routes for increment, decrement, and reset
app.post('/increment', requireLogin, (req, res) => {
    const counterRef = firebase.database().ref(`counters/${req.session.user}`);
    counterRef.transaction(count => count + 1, () => {
      res.redirect('/counter');
    });
  });
  
  app.post('/decrement', requireLogin, (req, res) => {
    const counterRef = firebase.database().ref(`counters/${req.session.user}`);
    counterRef.transaction(count => count - 1, () => {
      res.redirect('/counter');
    });
  });
  
  app.post('/reset', requireLogin, (req, res) => {
    const counterRef = firebase.database().ref(`counters/${req.session.user}`);
    counterRef.set(0, () => {
      res.redirect('/counter');
    });
  });
  
  // Start the server
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  