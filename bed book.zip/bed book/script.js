const MongoClient = require('mongodb').MongoClient;
const url = 'mongodb://localhost:27017';

MongoClient.connect(url, (err, client) => {
  if (err) {
    console.error('Failed to connect to MongoDB:', err);
    return;
  }
  console.log('Connected to MongoDB');

  const db = client.db('mydatabase');
  const collection = db.collection('mycollection');
  let count = 0;

  const decrementBtn = document.getElementById('decrement');
  const incrementBtn = document.getElementById('increment');
  const countSpan = document.getElementById('count');

  // Initialize count value from database
  collection.findOne({}, (err, doc) => {
    if (doc) {
      count = doc.count;
      countSpan.textContent = count;
    }
  });

  decrementBtn.addEventListener('click', () => {
    count--;
    countSpan.textContent = count;

    // Update count value in database
    collection.updateOne({}, { $set: { count } }, { upsert: true });
  });

  incrementBtn.addEventListener('click', () => {
    count++;
    countSpan.textContent = count;

    // Update count value in database
    collection.updateOne({}, { $set: { count } }, { upsert: true });
  });
});
