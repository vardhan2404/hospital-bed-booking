const express = require('express');
const mongodb = require('mongodb');

const app = express();
const port = process.env.PORT || 3000;
const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017';
const dbName = 'counter';

mongodb.MongoClient.connect(uri, { useNewUrlParser: true })
  .then(client => {
    console.log(`Connected to MongoDB at ${uri}`);

    const db = client.db(dbName);
    const collection = db.collection('counters');

    app.use(express.json());

    // Get the current count value
    app.get('/count', (req, res) => {
      collection.findOne()
        .then(doc => {
          if (doc) {
            res.json({ count: doc.count });
          } else {
            res.json({ count: 0 });
          }
        })
        .catch(err => {
          console.error(err);
          res.sendStatus(500);
        });
    });

    // Increment the count value
    app.post('/count/increment', (req, res) => {
      collection.findOneAndUpdate({}, { $inc: { count: 1 } }, { upsert: true, returnOriginal: false })
        .then(result => {
          res.json({ count: result.value.count });
        })
        .catch(err => {
          console.error(err);
          res.sendStatus(500);
        });
    });

    // Decrement the count value
    app.post('/count/decrement', (req, res) => {
      collection.findOneAndUpdate({}, { $inc: { count: -1 } }, { upsert: true, returnOriginal: false })
        .then(result => {
          res.json({ count: result.value.count });
        })
        .catch(err => {
          console.error(err);
          res.sendStatus(500);
        });
    });

    // Start the server
    app.listen(port, () => {
      console.log(`Server listening on port ${port}`);
    });
  })
  .catch(err => {
    console.error(`Failed to connect to MongoDB at ${uri}:`, err);
  });
