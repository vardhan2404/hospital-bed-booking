// server.js

const express = require('express');
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Connect to MongoDB database
MongoClient.connect('mongodb://localhost:27017', function(err, client) {
  if (err) throw err;
  const db = client.db('mydatabase');
  const counters = db.collection('counters');

  // GET route to retrieve counter value and history
  app.get('/counter', function(req, res) {
    counters.findOne({}, { sort: { timestamp: -1 } }, function(err, result) {
      if (err) throw err;
      res.send(result);
    });
  });

  // POST route to update counter value and history
  app.post('/counter', function(req, res) {
    const newCounter = {
      value: req.body.value,
      timestamp: new Date()
    };
    counters.insertOne(newCounter, function(err, result) {
      if (err) throw err;
      res.send(result);
    });
  });

  // Serve web page that displays the counter value and buttons
  app.get('/', function(req, res) {
    res.sendFile(__dirname + '/index.html');
  });

  app.listen(port, function() {
    console.log(`Server running at http://localhost:${port}`);
  });
});


